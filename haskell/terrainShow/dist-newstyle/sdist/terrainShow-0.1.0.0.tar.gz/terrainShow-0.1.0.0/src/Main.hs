import Prelude

main :: IO ()
main = putStrLn "Hello, Haskell!"
