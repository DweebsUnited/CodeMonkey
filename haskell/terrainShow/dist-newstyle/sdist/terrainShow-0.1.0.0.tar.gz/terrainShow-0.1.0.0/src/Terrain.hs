module Terrain where

terrain = 0